# tuplas: Colecciones ordenadas (con indice) pero son inmutables
# no podemos agregar, eliminar, modificar datos de una tupla
# igual que las listas permite elementos duplicados
# igual que el resto de colecciones los datos pueden ser de cualquier tipo
# se crean con ()
# Ejemplos de uso: meses del año, dias de la semana, estado civil, puntos cardinales

dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
print(type(dias)) # <class 'tuple'>
print(dias)

# crear una tupla vacia
tupla_vacia = ()
tupla_vacia = tuple()  # llamar al constructor de la clase tuple

# del dias[0] # TypeError: 'tuple' object doesn't support item deletion
# dias.append('otro sabado') # AttributeError: 'tuple' object has no attribute 'append'
# dias[0] = 'otro viernes' # TypeError: 'tuple' object does not support item assignment

# Mostrar el primer elemento de la tupla
print(dias[0])

# Longitud de la tupla (numero de elementos)
print(len(dias))

# Cuantos lunes hay en la tupla
print(dias.count("lunes"))

# En que posicion esta el viernes
print(dias.index("viernes")) # esta en el indice 4
print(dias.index("viernes", 2))
# print(dias.index("viernes", 5)) # ValueError: tuple.index(x): x not in tuple

''' unir o concatenar tuplas '''
# El orden es importante tupla = a + b  que tupla = b + a
# TypeError: can only concatenate tuple (not "str") to tuple
# otra_tupla = dias + ('otro_sabado') # si detecta que en la tupla solo hay un elemento -> ERROR

# con la , engañamos al interprete de Python para que crea que hay mas elementos
otra_tupla = dias + ('otro_sabado',)
print(otra_tupla)

# convertir una lista en tupla
otra_tupla = dias + tuple(['sabado', 'domingo'])
print(otra_tupla)

# convertir una tupla en lista
lista = list(otra_tupla)
print(lista)

# Igual que recorremos con fon in y for range las listas, las tuplas igual

# Los slices funcionan igual
# Mostrar los dias laborables 
print(otra_tupla[0:5]) # recordar que el ultimo no se incluye

# Mostrar los dias de la semana en orden inverso
print(dias[::-1])

# Otra forma de crear tuplas
numeros = 1,2,3,4,5
print(type(numeros)) # <class 'tuple'>

# Funciones universales que funcionan con las colecciones (list, tuple, set, dict)
print(len(numeros)) # 5 elementos
print(min(numeros)) # 1
print(max(numeros)) # 5
print(sum(numeros)) # 15
print(sorted(numeros, reverse=True)) # [5, 4, 3, 2, 1] como una lista

print("-----------------------------------")
separador = "-" * 30
print(separador)

# Esto tambien se puede hacer con listas
duplicar_elementos = numeros * 2
print(duplicar_elementos)