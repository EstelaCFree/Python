'''
    Crear la clase Cliente con propiedades: nombre, cif, vip:bool y un metodo mostrarInfo
    crear 2 clientes y mostrar la informacion
    
    Crear la clase Direccion con propiedades: calle, numero, poblacion
    Modificar la clase Cliente para que tenga una propiedad direccion
    tambien hay que modificar mostrarInfo en la clase Cliente
'''
class Direccion:
    def __init__(self, calle, numero, poblacion):
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        

class Cliente:
    def __init__(self, nombre, cif, vip, direccion):
        self.nombre = nombre
        self.cif = cif
        self.vip = vip
        self.direccion = direccion # composicion: la propiedad es un objeto
        
    def mostrarInfo(self):
        print(f"Nombre: {self.nombre}, CIF: {self.cif}, VIP: {self.vip}" +
              f" Direccion: {self.direccion.calle}, {self.direccion.numero} ({self.direccion.poblacion}) ")

dir = Direccion("Mayor", 5, "Madrid")       
cliente1 = Cliente("Fruteria Paco", "B-12345678", False, dir)

cliente2 = Cliente("Ferreteria Amparo", "B-98765432", True, Direccion("Diagonal", 36, "Barcelona"))

cliente1.mostrarInfo()
cliente2.mostrarInfo()

print(cliente1.direccion.poblacion)