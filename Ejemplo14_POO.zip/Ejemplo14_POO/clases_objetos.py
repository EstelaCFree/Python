class Persona:
    
    # En Python solo se permite un constructor por clase
    def __init__(self, nombre, edad):
        # Crear propiedades, atributos, campos, variables de instancia
        self.nombre = nombre
        self.edad = edad
    
    # Metodo: Son funciones declaradas dentro de la clase    
    def nombre_mayusculas(self) -> str:
        return self.nombre.upper()
    
    def mostrar_info(self) -> None:
        print(f"Nombre: {self.nombre}, Edad: {self.edad}")



# Crear un objeto de Persona
persona1 = Persona("Maria", 35)
persona2 = Persona("Juan", 28)

# . es el operador de acceso a miembro
persona1.nombre = "Maria Jose"
persona1.edad = 36

print(persona1.nombre_mayusculas())
persona1.mostrar_info()
persona2.mostrar_info()