'''
    crear una funcion que recibe una palabra y RETORNA el numero de vocales que tiene
    probarla con varias peticiones
'''
def contar_vocales(palabra) -> int:
    contador = 0
    
    for letra in palabra.lower():
        if letra in "aeiou":
            contador += 1
    
    return contador

print(f"La palabra mesa tiene {contar_vocales('mesa')} vocales")
print(f"La palabra frigorifico tiene {contar_vocales('frigorifico')} vocales")
print(f"La palabra arbol tiene {contar_vocales('arbol')} vocales")
print(f"La palabra codigo tiene {contar_vocales('codigo')} vocales")
print(f"La palabra portatil tiene {contar_vocales('portatil')} vocales")