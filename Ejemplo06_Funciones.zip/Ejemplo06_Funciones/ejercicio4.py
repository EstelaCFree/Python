'''
    crear una funcion area_triangulo que recibe los argumentos necesarios para calcular el area
    la funcion retorna el resultado
    solicitar los datos por teclado
'''
def area_triangulo(base, altura):
    return base * altura / 2

dato1 = float(input("Introduce la base del triangulo: "))
dato2 = float(input("Introduce la altura del triangulo: "))

print(f"{area_triangulo(dato1, dato2):.2f}")