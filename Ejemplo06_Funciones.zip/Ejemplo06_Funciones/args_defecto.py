def datos_trabajador(nombre, estado_civil="soltero", sueldo=21000):
    print(f"{nombre} esta {estado_civil} y gana {sueldo}")

# por kwargs
datos_trabajador("Juan")
datos_trabajador("Maria", sueldo=25000)
datos_trabajador("Antonio", sueldo=30000)

# Por posicion
datos_trabajador("Antonio", 'casado', 30000)