'''
    Crear una funcion que recibe un texto y retorna:
        - Texto en mayusculas upper()
        - Texto en minusculas lower()
        - Longitud del texto
'''

def procesar_texto(texto: str) -> tuple:
    return texto.upper(), texto.lower(), len(texto)

# Recojo los valores con 3 variables
mayusculas, minusculas, longitud = procesar_texto("Hola, que tal?")
print(mayusculas)
print(minusculas)
print(longitud)

# Recojo los valores en una tupla
tupla = procesar_texto("Hola, que tal?")
print(tupla[0])
print(tupla[1])
print(tupla[2])

for elemento in tupla:
    print(elemento)