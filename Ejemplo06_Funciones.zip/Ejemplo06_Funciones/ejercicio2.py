'''
    crear una funcion calcular_precio recibe el precio del producto y el porcentaje de dto (10)
    retornar el precio final
    
    probar con diferentes precios y descuentos
'''
def calcular_precio(precio, dto) -> float:
    importe_dto = precio * dto / 100
    nuevo_precio = precio - importe_dto
    return nuevo_precio

print(calcular_precio(24.56, 10))
print(calcular_precio(18, 5))
print(f"{calcular_precio(100, 20)}")
print(f"{calcular_precio(225, 25)}")