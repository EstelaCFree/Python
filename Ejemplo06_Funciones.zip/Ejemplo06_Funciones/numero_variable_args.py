# crear una funcion que pueda recibir 0 elementos, 1 elemento, 2 elementos, ....
# a esto se le llama: numeri variable de argumentos

def sumar(*numeros):
    print(type(numeros)) # <class 'tuple'>
    suma = 0
    for num in numeros:
        suma += num
    return suma
        
print(sumar())  # 0
print(sumar(3,1))  # 4
print(sumar(3,1,8))  # 12
print(sumar(3,1,8,4,6,9)) # 31


# Ejercicio
'''
    Crear una funcion que recibe el nombre del alumno y las notas de las asignaturas en las que esta matriculado
    retornar el nombre del alumno en mayusculas  y la media de las notas
    IMPORTANTE, cuando se trabaja con numero variable de argumentos VA AL FINAL
'''
def calcular_media(nombre, *notas) -> tuple:
    #  notas es una tupla
    #  *notas paso los datos de la tupla
    if len(notas) > 0:
        nota_media = sumar(*notas) / len(notas)
    else:
        nota_media = 0 
    return nombre.upper(), nota_media   
    

print(calcular_media('Jorge'))
print(calcular_media('Jorge',6))
print(calcular_media('Jorge', 6,9))
print(calcular_media('Jorge', 6,9,7,8,5,8))