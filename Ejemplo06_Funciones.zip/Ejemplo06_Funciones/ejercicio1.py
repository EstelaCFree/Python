'''
    solicitar 2 numeros al usuario y ejecutas las 4 operaciones
    crear una calculadora con 5 funciones
        sumar, restar, multiplicar, dividir que muestran el resultado en la consola
        validar_divisor retornar un valor True o False para indicar si se puede hacer la division o no
'''
'''
dividir(7,0)
   llamar a validar_divisor(0). devuelve False
   lo siento no puedo hacer la division
   
dividir(7,2)
   llamar a validar_divisor(2). devuelve True
   muestro el resultado de la division
'''
def sumar(n1: int, n2: int) -> int:
    suma = n1 + n2
    print(f"{n1} + {n2} = {suma}")

def restar(n1: int, n2: int) -> int:
    resta = n1 - n2
    print(f"{n1} - {n2} = {resta}")

def multiplicar(n1: int, n2: int) -> int:
    multiplicacion = n1 * n2
    print(f"{n1} * {n2} = {multiplicacion}")

def dividir(n1: int, n2: int) -> float:
    correcto = validar_divisor(n2)
    if correcto == True:
        division = n1 / n2
        print(f"{n1} / {n2} = {division}")
    else:
        print("Lo siento no puedo hacer la division")

def validar_divisor(divisor: int) -> bool:
    if divisor == 0:
        return False
    else:
        return True
    
numero1 = int(input("Introduce el primer numero: "))
numero2 = int(input("Introduce el segundo numero: "))

# Invocar o llamar a las funciones
sumar(numero1, numero2)
restar(numero1, numero2)
multiplicar(numero1, numero2)
dividir(numero1, numero2)