import datetime

# Fecha y hora actual
print("Ahora:", datetime.datetime.today())
print("Ahora:", datetime.datetime.now())

# Fecha y hora
fecha_hora = datetime.datetime(2027, 1, 26, 8, 30)
print(fecha_hora)

# Mostrar solo la fecha con formato
print(fecha_hora.date().strftime('%d/%m/%Y')) # 26/01/2027
print(fecha_hora.date().strftime('%d/%m/%y')) # 26/01/27

# Mostrar solo la hora con formato
print(fecha_hora.time().strftime('%H:%M:%S')) # 08:30:00