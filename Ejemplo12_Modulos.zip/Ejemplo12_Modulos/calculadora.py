
# 1ª forma: importar el modulo completo
import operaciones
print(operaciones.sumar(6, 2))


# 2ª forma: importar el recurso del modulo que necesito
from operaciones import restar
print(restar(8,3))


# 3ª forma: importar el recurso del modulo con alias
from operaciones import dividir as div
#print(dividir(8,4)) # No funciona, lo tengo que utilizar con el alias
print(div(8,4))