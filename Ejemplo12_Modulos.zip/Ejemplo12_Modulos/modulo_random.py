from random import random, randrange, randint, choice, sample

# Para generar numeros aleatorios entre 0 y 1 pero sin llegar 1
print(random())

# Generar un numero aleatorio hasta el 10 (SIN INCLUIR)
print(randrange(10))
print(randrange(8,10))

# Generar un numero aleatorio desde 8 hasta el 10 (SI LO INCLUYE)
print(randint(8,10))

# crear un bucle que genere 5 numeros aleatorios entre 20 y 30
for num in range(5):
    print("Numero aleatorio:", randint(20,30))
    
''' Importante: los metodos randrange y randint pueden devolver numeros repetidos'''
    
# Generar numeros aleatorios sin duplicados
# choice: retorna un elemento aleatorio de una secuencia pasada como argumento lista o tupla
print("Choice:", choice( [1,2,3,4,5,6] ))
print("Choice:", choice( (1,2,3,4,5,6) ))

# sample: retorna el numero de elementos especificados aleatorios en una lista
# de una secuencia pasada como argumento lista o tupla
print("Sample:", sample( [1,2,3,4,5,6], 3 ))
print("Sample:", sample( [1,2,3,4,5,6], 5 ))
print("Sample:", sample( (1,2,3,4,5,6), 3 ))

# generar 6 numeros del 1 al 49
print("Primitiva:", sample( range(1,50), 6))
print("Quien pone la mesa y quien la recoge:", sample( ["Luis", "Marta", "Pedro", "Laura"], 2 ))
