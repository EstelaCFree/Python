import math

print("Potencia 2 elevado a 8:", math.pow(2,8))
print("PI:", math.pi)
print("Logaritmo base 10 1000", math.log(1000))
print("Seno de 90:", math.sin(math.radians(90)))
print("Factorial de 4:", math.factorial(4))
print("Raiz cuadrada de 9:", math.sqrt(9))

# Redondeos
print("Redondear a 2 decimales 6,765456:", round(6.765456, 2))

print("Redondeo al alza 3.89:", math.ceil(3.89)) # 4
print("Redondeo al alza 3.19:", math.ceil(3.19)) # 4
print("Redondeo al alza -3.19:", math.ceil(-3.19)) # -3

print("Redondeo a la baja 3.89:", math.floor(3.89)) # 3
print("Redondeo a la baja 3.19:", math.floor(3.19)) # 3
print("Redondeo a la baja -3.19:", math.floor(-3.19)) # -4

print("Truncar 3.89:", math.trunc(3.89)) # 3
print("Truncar 3.19:", math.trunc(3.19)) # 3
print("Truncar -3.89:", math.trunc(-3.89)) # -3