# lista de una dimension
lista = [1,2,3,4,5] # un solo indice -> un bucle para recorrer

# listas de 2 dimensiones
matriz = [ [2,7,4], [8,1,6], [3,9,5] ]  # 2 indices (fila, columna) -> 2 bucles

'''
    2   7   4
    8   1   6
    3   9   5
    
    4 -> fila 0 y columna 2
    9 -> fila 2 y columna 1
    8 -> fila 1 y columna 0
'''
for fila in matriz:
    for numero in fila:
        print(numero, end="\t")
    else:
        print()
        
for idx_fila in range(len(matriz)):
    for idx_columna in range(len(matriz[idx_fila])):
        print(matriz[idx_fila][idx_columna], end="\t")
    else:
        print()
        
print(matriz[0][2])
print(matriz[2][1])
print(matriz[1][0])
