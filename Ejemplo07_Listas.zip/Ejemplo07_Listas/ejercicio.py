# crear una lista llamada colores con los valores rojo, verde y azul
colores = ["rojo", "verde", "azul"]

# mostrar el tipo de dato de la coleccion
print(type(colores))

# mostrar el contenido de la lista
print(colores)

# recorrer la lista con for in
for color in colores:
    print(color, end=" ")

# recorrer la lista con for range
for idx in range(len(colores)):
    print(colores[idx], end=" ")

# recorrer la lista con while
idx = 0
while idx < len(colores):
    print(colores[idx], end=" ")
    idx += 1
print()

# mostrar el color verde (acceder por el indice)
print(colores[1])

# borrar el color azul
del colores[2]
#del colores[-1]
print(colores)

# crear una lista vacia mas_colores
mas_colores = []

# en la lista nueva unir el contenido de la lista colores con: blanco, negro, rosa, azul
mas_colores = colores + ["blanco", "negro", "rosa", "azul"]
print(mas_colores)

# agregar el color naranja al final
mas_colores.append("naranja")

# agregar el color marron al principio
mas_colores.insert(0, "marron")
print(mas_colores)

# mostrar la longitud de la lista
print(len(mas_colores))

# mostrar el antepenultimo elemento
print(mas_colores[-3])

# Ordenar los elementos
mas_colores.sort() # ascendente
print("Lista ordenada:", mas_colores)

# Ordenar los elementos
mas_colores.sort(reverse=True) # descendente
print("Lista ordenada:", mas_colores)

''' slices '''
# Mostrar los 2 ultimos elementos
print(mas_colores[-2:])

# Mostrar desde el ultimo hasta el antepenultimo
print(mas_colores[-1:-4:-1])

# Mostrar los 3 primeros
print(mas_colores[:3])

# Mostrar del segundo al cuarto
print(mas_colores[1:4])

# Mostrar del primero al penultimo de 2 en 2
print(mas_colores[:-1:2])

# eliminar todos los elementos de la lista
mas_colores.clear()
print(mas_colores)

