# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones los elementos pueden ser de diferentes tipos
# permite elementos duplicados
# son mutables: permite modificar, añadir, eliminar
# Se crean []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]

# tipo de las listas
print(type(list1)) # <class 'list'>

# mostrar las listas
print(list1)
print(list2)

# crear una lista vacia
lista_vacia = []
lista = list()

# unir listas (el orden es importante)
lista_vacia = list1 + list2
print(lista_vacia)
lista = list2 + list1
print(lista)

# longitud de la lista (numero de elementos)
print("La longitud de la lista:", len(lista)) # len es una funcion porque esta declarada de forma independiente

# Acceso a los elementos de la lista
# si el indice es positivo comenzamos por la izquierda [0]
# si el indice es negativo comenzamos por la derecha [-1]
print("codigo postal:", lista[2])
print("estado civil:", lista[-2])
print("estado civil:", lista[len(lista) -2]) # lista[8-2] lista[6]

# Agregar un elemento al final de la lista
lista.append("morena") # append es un metodo porque esta declarado dentro de la clase list
print(lista)

# Agregar elemento en una determinada posicion
lista.insert(0, 1.72)
print(lista)

# Agregar varios elementos a la vez al final
lista.extend([1,2,3])
print(lista)

# Eliminar un elemento de la lista por indice
del lista[-1]
print(lista)

# Eliminar un elemento de la lista por valor
lista.remove('morena')
print(lista)

# Modificar un elemento de la lista
lista[-4] = "1 hijo"
print(lista)

# Mostrar el indice donde esta "medicina"
print("Medicina esta en el indice", lista.index("medicina"))
# ValueError: list.index(x): x not in list
#print("Medicina esta en el indice", lista.index("medicina", 6))

# Contar cuantos elementos 'estudiante' tengo
print("Tengo", lista.count('estudiante'), "elementos 'estudiante'")

# Recorrer la lista for in
for elemento in lista:
    print(elemento, end="-")
else: # se ejecuta cuando no tengo mas elementos
    print("\n-----------")
    
# Recorrer la lista for range
for indice in range(len(lista)): # rango del 0 al 11
     print(lista[indice], end="-") # el indice va entre corchetes sea una lista u otra coleccion
else: 
    print("\n-----------")
    
# Recorrer la lista while
idx = 0
while(idx < len(lista)):
    print(lista[idx], end="-")
    idx += 1
else: 
    print("\n-----------")
    

''' slices [begin:stop:step] el ultimo no entra '''
# Mostrar todos los elementos
print("Todos", lista[:])

# Mostrar los ultimos 4 elementos
print("Ultimos 4", lista[-4:])

# Mostrar los 5 primeros
print("5 primeros", lista[0:5]) # igual que los rangos el ultimo no entra
print("5 primeros", lista[:5])

# Mostrar los elementos del indice 3 al indice 6
print("Del 3 al 6", lista[3:7])

# Mostrar los elementos del indice 6 al indice 3
print("Del 6 al 3", lista[6:2]) # vacio
print("Del 6 al 3", lista[6:2: -1])

# Mostrar los elementos del indice 6 al indice 3 pero por la derecha
print("Del 6 al 3", lista[-6:-10: -1])
print("Del 6 al 3", lista[-6:2: -1])

# Mostrar todos en orden inverso
print("Todos", lista[::-1])

# Mostrar todos en orden inverso de 2 en 2
print("Todos", lista[::-2])

# Mostrar todos de 2 en 2
print("Todos", lista[::2])

''' Operadores de pertenencia: in y not in '''
print("hola" in lista)
print("medicina" in lista)
print("hola" not in lista)

