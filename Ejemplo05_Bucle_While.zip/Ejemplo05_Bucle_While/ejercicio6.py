'''
    Juan y Miguel participan en una carrera de 10 km.
    Cada participante avanza en km segun el dado que salga
    Juan: 1 + 3 + 5 + 2 = 11
    Miguel: 6 + 1 + 4 = 11
    Mostrar quien es el ganador o si hay empate
'''
import random

juan = 0
miguel = 0

while juan < 10 and miguel < 10:
    juan += random.randint(1,6)
    miguel += random.randint(1,6)
    
    print(f"Juan va por el km {juan}")
    print(f"Miguel va por el km {miguel}")
    
if juan >= 10 and miguel < 10:
    print("Juan campeon")
elif juan < 10 and miguel >= 10:
    print("Miguel campeon")
else:
    print("Empate")