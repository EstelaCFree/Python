'''
    Solicitar numeros al usuario hasta que introduzca "FIN"
    Vamos sumando los numeros y al final mostrar el resultado
'''
resultado = 0
dato = ""
while dato != "FIN":
    dato = input("Introduce numero: ")
    if dato != "FIN":
        numero = int(dato)
        resultado += numero
print(resultado)