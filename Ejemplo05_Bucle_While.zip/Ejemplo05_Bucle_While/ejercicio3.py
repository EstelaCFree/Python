'''
    import os
    os.system("cls") # windows
    os.system("clear") # linux o mac
    
    Mostrar este menu de cajero al usuario:
        1. Consultar el saldo
        2. Ingresar dinero (solicitar la cantidad a ingresar)
        3. Retirar dinero (solicitar la cantidad, comprobar que hay saldo suficiente)
        4. Salir de la aplicacion
'''

saldo = 0
opcion = 0
while opcion != 4:
    print('''
        1. Consultar el saldo
        2. Ingresar dinero 
        3. Retirar dinero
        4. Salir de la aplicacion
    ''')
    opcion = int(input("Introduce opcion: "))
    
    if opcion == 1:
        print(f"Tu saldo es {saldo}")
        
    elif opcion == 2:
        cantidad = float(input("Introduce la cantidad a ingresar: "))
        saldo += cantidad
        print(f"Ingreso realizado, tu nuevo saldo es {saldo}")
        
    elif opcion == 3:
        cantidad = float(input("Introduce la cantidad a retirar: "))
        if saldo >= cantidad:
            saldo -= cantidad
            print(f"Cantidad retirada, tu nuevo saldo es {saldo}")
        else:
            print("No tienes saldo suficiente")
            
    elif opcion != 4:
        print("Opcion incorrecta")