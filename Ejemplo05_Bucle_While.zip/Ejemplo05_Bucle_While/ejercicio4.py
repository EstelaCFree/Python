'''
    Generar un numero aleatorio del 1 al 10
    Solicitar al usuario que lo adivine.
    Le teneis que dar pistas
'''
import random
numero = random.randint(1,10)
adivinar = 0
while adivinar != numero:
    adivinar = int(input("Adivina el numero: "))
    if adivinar < numero:
        print("Te has quedado corto, vuelve a intentarlo")
    elif adivinar > numero:
        print("Te has pasado, vuelve a intentarlo")
    else:
        print("Enhorabuena, lo adivinaste")