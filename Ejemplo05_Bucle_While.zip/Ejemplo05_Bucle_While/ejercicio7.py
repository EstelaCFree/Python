'''
    Mostrar el menu:
        1. Piedra
        2. Papel
        3. Tijera
        El usuario elije (1-3)
    El ordenador genera un numero aleatorio (1-3)
    
    -  El papel envuelve la piedra
    -  La tijera corta el papel
    -  La piedra machaca la tijera
'''
import random
ordenador = random.randint(1,3)
usuario = int(input("Introduce 1-Piedra, 2-Papel, 3-Tijera: "))
campeon = False

while campeon:
    if (ordenador == usuario):
        print("empate")
        
    ordenador = random.randint(1,3)
    usuario = int(input("Introduce 1-Piedra, 2-Papel, 3-Tijera: "))
    
    if ordenador == 2 and usuario == 1:
        print("Ordenador campeon")
        campeon = True
    elif ordenador == 1 and usuario == 2:
        print("Usuario campeon")
        campeon = True
    elif ordenador == 3 and usuario == 2:
        print("Ordenador campeon")
        campeon = True
    elif ordenador == 2 and usuario == 3:
        print("Usuario campeon")
        campeon = True
    elif ordenador == 1 and usuario == 3:
        print("Ordenador campeon")
        campeon = True
    elif ordenador == 3 and usuario == 1:
        print("Usuario campeon")
        campeon = True
