'''
    Mostrar el menu:
        1. Piedra
        2. Papel
        3. Tijera
        El usuario elije (1-3)
    El ordenador genera un numero aleatorio (1-3)
    
    -  El papel envuelve la piedra
    -  La tijera corta el papel
    -  La piedra machaca la tijera
'''
import random

continuar = ""
while continuar != "N":

    # El usuario elige
    usuario = int(input("Elige 1-Piedra, 2-Papel, 3-Tijera: "))

    # Comprobar que la opción sea correcta
    if usuario < 1 or usuario > 3:
        print("Opción no válida")
    else:
        # El ordenador elige aleatoriamente
        ordenador = random.randint(1, 3)

        print("El ordenador ha elegido:", ordenador)

        # Comprobar quién gana
        if usuario == ordenador:
            print("¡EMPATE!")

        elif (usuario == 1 and ordenador == 3) or \
             (usuario == 2 and ordenador == 1) or \
             (usuario == 3 and ordenador == 2):
            print("¡GANA EL USUARIO!")

        else:
            print("¡GANA EL ORDENADOR!")

    # Preguntar si quiere seguir jugando
    continuar = input("¿Quieres jugar otra vez? (Y/N): ")

print("Chao chao!")