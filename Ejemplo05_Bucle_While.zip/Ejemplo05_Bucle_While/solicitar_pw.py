'''
    Solicitar el password al usuario hasta que acierte que es "curso"
'''
pw = ""
while pw != "curso":
    pw = input("Introduce PW: ")
    
print("Password correcta")