# Mostrar los numeros del 1 al 10
num = 1
while num <= 10:
    print(num)
    num += 1
    