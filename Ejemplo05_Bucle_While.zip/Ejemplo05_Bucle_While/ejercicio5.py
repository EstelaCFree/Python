'''
    Tirar el dado hasta que salga el numero 6
    Generar un numero aleatorio entre 1 y 6
    Mostrar numero generado
'''
import random
lanzamiento = 0
contador = 0

while(lanzamiento != 6):
    lanzamiento = random.randint(1,6)
    contador += 1
    print("Resultado:", lanzamiento)
    
print("Se ha lanzado", contador, "veces el dado")