'''
    solicitar un numero al usuario, mostrar desde 0 hasta ese numero, solo los pares
    8 -> 0,2,4,6
    11 -> 0,2,4,6,8,10
'''
numero = int(input("Introduce numero: "))

num = 0
while num < numero:
    if num % 2 == 0:
        print(num)
    num += 1