'''
    Sustituir Java por Python
    Cuantas veces aparece la palabra Java
    Comprobar si empieza por "Me gusta"
    Comprobar si termina por divertido
    Longitud
    Caracter maximo y minimo
    Poner en mayusculas
    Porner en minusculas
'''

frase = "Me gusta Java porque Java es divertido"

# Sustituir Java por Python
print(frase.replace("Java", "Python"))

# Cuantas veces aparece la palabra Java
print(frase.count("Java"))

# Comprobar si empieza por "Me gusta"
print(frase.startswith("Me gusta"))

# Comprobar si termina por divertido
print(frase.endswith("divertido"))

# Longitud
print(len(frase))

# Caracter maximo y minimo
print(max(frase))
print(min(frase))

# Poner en mayusculas
print(frase.upper())

# Poner en minusculas
print(frase.lower())