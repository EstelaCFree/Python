texto = "bienvenidos al curso de Python"

# Mayusculas y minusculas
print(texto.capitalize()) # Solo la primera letra en mayuscula y el resto en minusculas
print(texto.title()) # En mayuscula la primera letra de cada palabra
print(texto.upper()) # Todo el texto en mayusculas
print(texto.lower()) # Todo el texto en minusculas
print(texto.swapcase()) # intercambia mayusculas por minusculas

# isalnum: True si solo hay letras y numeros, cualquier otro caracter es False
print("isalnum", texto.isalnum()) # False por los espacios en blanco
print("isalnum", "hola".isalnum()) # True
print("isalnum", "1234".isalnum()) # True
print("isalnum", "hola1234".isalnum()) # True
print("isalnum", "hola_1234".isalnum()) # False por _

# isalpha: True si solo hay letras, cualquier otro caracter es False
print("isalpha", texto.isalpha()) # False por los espacios en blanco
print("isalpha", "hola".isalpha()) # True
print("isalpha", "1234".isalpha()) # False por los numeros
print("isalpha", "hola1234".isalpha()) # False por los numeros
print("isalpha", "hola_1234".isalpha()) # False por _ y los numeros

# isdigit: True si solo hay numeros, cualquier otro caracter es False
print("isdigit", texto.isdigit()) # False por los espacios en blanco y letras
print("isdigit", "hola".isdigit()) # False por las letras
print("isdigit", "1234".isdigit()) # True 
print("isdigit", "hola1234".isdigit()) # False por las letras
print("isdigit", "hola_1234".isdigit()) # False por _ y las letras

# isupper: True si solo hay mayusculas, el resto de los caracteres los ignora
print("isupper", texto.isupper()) # False porque hay minusculas
print("isupper", "HOLA".isupper()) # True
print("isupper", "1234".isupper()) # False 
print("isupper", "HOLA1234".isupper()) # True
print("isupper", "HOLA_1234".isupper()) # True

# islower: True si solo hay minusculas, el resto de los caracteres los ignora
print("islower", texto.islower()) # False porque hay mayusculas
print("islower", "hola".islower()) # True
print("islower", "1234".islower()) # False 
print("islower", "hola1234".islower()) # True
print("islower", "hola_1234".islower()) # True

print("Longitud:", len(texto))

# La tabla ASCII esta ordenada (1º numeros, 2º mayusculas, 3º minusculas)
print("Maximo:", max(texto))
print("Minimo:", min(texto)) # es el espacio en blanco

ejemplo = "     Hoy es lunes    "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n") # Elimina los espacios de la izquierda
print("rstrip", ejemplo.rstrip(), end=".\n") # Elimina los espacios de la derecha
print("strip", ejemplo.strip(), end=".\n") # Elimina los espacios de la izquierda y derecha
prueba = "...........hola..........."
print("strip", prueba.strip("."), end="\n")

palabras = texto.split() # Por defecto trocea la cadena por el espacio en blanco
print(type(palabras)) # <class 'list'>
print(palabras) # ['bienvenidos', 'al', 'curso', 'de', 'Python']
fecha = "24/11/2026"
lista = fecha.split("/")
print("Dia:", lista[0])
print("Mes:", lista[1])
print("Año:", lista[2])

print("replace", texto.replace("e", "E")) # Reemplaza todas las letras e por E
print("replace", texto.replace("o", "O", 2)) # Reemplaza dos letras o por O

print("find", texto.find("o")) # retorna el indice donde encuentra la primera letra o
print("find", texto.find("o", 11)) # retorna el indice donde encuentra la primera letra o a partir del indice 11
print("find", texto.find("o", 10, 20)) # el ultimo no esta incluido
print("find", texto.find("W")) # -1 porque no existe
print("rfind", texto.rfind("o")) # 28 porque empieza a buscar por la derecha

print(ord("A")) # 65 es la posicion en la tabla ASCII
print(chr(65)) # A

print("Cuantas e tengo?", texto.count("e")) # 3

print(sorted(texto)) # [' ', ' ', ' ', ' ', 'P', 'a', 'b', 'c', 'd', 'd', 'e', 'e', 'e', 'h', 'i', 'i', 'l', 'n', 'n', 'n', 'o', 'o', 'o', 'r', 's', 's', 't', 'u', 'v', 'y']

print("Empieza por b?", texto.startswith("b")) # True
print("Termina en Python?", texto.endswith("Python")) # True

# Retorna un texto con los elementos de la coleccion palabras unidos por el texto "-"
print("-".join(palabras)) # bienvenidos-al-curso-de-Python