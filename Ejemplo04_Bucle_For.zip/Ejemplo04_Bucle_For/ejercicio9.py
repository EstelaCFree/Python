'''
    Mostrar los 100 primeros terminos de la serie de Fibonacci
    OJO!!! no hasta el numero 100
'''
termino1 = 0
termino2 = 1
print(termino1, termino2, sep=", ", end=", ")

for num in range(1, 99):
    termino3 = termino1 + termino2
    print(termino3, end=", ")
    
    # cambiar posiciones
    termino1 = termino2
    termino2 = termino3