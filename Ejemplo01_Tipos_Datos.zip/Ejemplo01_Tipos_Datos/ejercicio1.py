'''
    Solicitar al usuario: nombre, apellido y la edad
    Mostrar un mensaje de bienvenida con esos datos 
'''

nombre = input("Introduce tu nombre: ")
apellido = input("Introduce tu apellido: ")
edad = input("Introduce tu edad: ")

print("Bienvenid@", nombre, apellido, "y tienes", edad, "años")
# otra forma de mostrar informacion:   f"literal {variable}"
print(f"Bienvenid@ {nombre} {apellido} y tienes {edad} años")
