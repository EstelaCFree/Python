'''
    solicitar una cantidad de segundos y mostrar el equivalente a horas, minutos, segundos
    1 hora son 3600 segundos
    Ejemplo:  la entrada 3675 segundos
              la salida  1 hora, 1 minuto y 15 segundos
'''

segundos = int(input("Introduce una cantidad en segundos: "))

horas = segundos // 3600  # Division entera
resto = segundos % 3600 # crear la variable resto

minutos = resto // 60
segundos_finales = resto % 60  # cambiar el valor de la variable resto

print(f"{horas} horas, {minutos} minutos y {segundos_finales} segundos ")