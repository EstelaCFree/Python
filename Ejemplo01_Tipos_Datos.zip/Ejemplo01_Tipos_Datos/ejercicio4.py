'''
    Conversion de grados centigrados a Fahrenheit
    Solicitar la temperatura en grados centigrados (float)
    aplicar la formula para obetener los grados Fahrenheit
        F = C x 9/5 + 32
        °F = (°C × 9/5) + 32
'''

grados_centigrados = float(input("Introduce los grados centigrados: "))
grados_fahrenheit = grados_centigrados * 9 / 5 + 32
print(f"{grados_centigrados}ºC equivalen a {grados_fahrenheit:.2f}ºF")