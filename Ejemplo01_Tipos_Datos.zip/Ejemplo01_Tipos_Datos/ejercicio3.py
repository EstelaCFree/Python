'''
    Solictar el precio como numero real de un producto,
        - aplicar el 10% de dto
        - aplicar 21% de IVA
        
    Mostrar el desglose: precio inicial, importe dto, importe IVA, importe total
'''

precio = float(input("Introduce el precio del producto: "))
descuento = 10
importe_descuento = precio * descuento / 100
precio_con_dto = precio - importe_descuento
importe_iva = precio_con_dto * 21 / 100
precio_final = precio - importe_descuento + importe_iva

print("Precio original:", precio)
print("Descuento aplicado:", round(importe_descuento, 2))
print(f"Importe IVA: {importe_iva:.2f}" )
print(f"Precio final: {precio_final:.2f}")