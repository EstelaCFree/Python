'''
    solicitar el importe en euros
    solicitar a como esta el cambio a dolares
    mostrar la conversion: x euros son x dolares 
'''

euros = float(input("Introduce el importe en euros: "))
cambio_dolar = float(input("Introduce el cambio a dolar: "))
dolares = euros * cambio_dolar
print(f"{euros}€ equivalen a {dolares}$")  

'''
    "literal"
    {variable}
'''