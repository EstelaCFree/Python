numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes
print(numeros1.intersection(numeros2))
print(numeros1 & numeros2)

# diferencia de conjuntos: elementos de un conjunto que no estan en otro
print(numeros1.difference(numeros2))
print(numeros1 - numeros2)

# el orden es importante
print(numeros2.difference(numeros1))
print(numeros2 - numeros1)

# union de conjuntos
print(numeros1.union(numeros2))
print(numeros1 | numeros2)

# diferencia simetrica de conjuntos: la union de conjuntos menos los comunes
print(numeros1.symmetric_difference(numeros2))
print(numeros1 ^ numeros2)