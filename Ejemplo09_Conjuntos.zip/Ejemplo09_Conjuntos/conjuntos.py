# conjuntos: colecciones sin orden (no usamos indices)
# No permiten elementos duplicados, los ignora
# Son colecciones mutables, permite agregar, eliminar, modificar
# No se garantiza el orden de entrada de los elementos
# Como en todas las colecciones, elementos pueden ser de diferentes tipos
# Se crean utilizando {}
# IMPORTANTE: conjunto = {} python lo interpreta como un diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(type(frutas)) # <class 'set'>
print(frutas)

# conjunto vacio
conjunto_vacio = {} # <class 'dict'>
print(type(conjunto_vacio))

conjunto_vacio = set() # constructor de la clase set

# agregar elementos
frutas.add('fresas')
print(frutas)

# eliminar elementos
# del borra por indice
frutas.remove('platano')
print(frutas)

# longitud del conjunto
print(len(frutas)) # 4

# copiar un conjunto en otro
otro = frutas.copy()

# unir conjuntos
# TypeError: unsupported operand type(s) for +: 'set' and 'set'
#resultado = frutas + {'melon', 'sandia'}
resultado = frutas.union({'melon', 'sandia'})

# Recorrer conjuntos con for in
for fruta in resultado:
    print(fruta, end=" ")
print()

# Convertir el conjunto a tupla
tupla = tuple(resultado)

# Convertir el conjunto a lista
lista = list(resultado)

# Operadores de pertenencia: in y not in
print('maracuya' in frutas)
print('fresas' in frutas)
print('melocoton' not in frutas)

# eliminar todo los elementos del conjunto
frutas.clear()
print(frutas) # set()