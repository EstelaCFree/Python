# Diccionarios: los elemenos son key:value
# No tienen indices pero se accede a traves de la clave
# A partir 3.7 se garantiza el orden de entrada
# Las claves no se pueden repetir, se sobreescribe su valor
# Pero los valores si se pueden repetir
# Se crean con {}

alumnos = {'Juan': 6.4, 'Maria': 8.3, 'Luis': 6.4, 'Adolfo': 7.1, 'Maria': 9.3}
print(type(alumnos)) # <class 'dict'>
print(alumnos)

# crear diccionario vacio
vacio = {}
vacio = dict()

# Mostrar solo las claves, los nombres de los alumnos
print(alumnos.keys())

# Mostrar solo los values, las notas de los alumnos
print(alumnos.values())

# Mostrar todos los elementos del diccionario
print(alumnos.items())

# Accedemos a los elementos a través de su clave
print("Nota de Luis:", alumnos['Luis'])
print("Nota de Luis:", alumnos.get('Luis'))

# print("Nota de Luis:", alumnos['Luissssssss']) # KeyError: 'Luissssssss'
print("Nota de Luis:", alumnos.get('Luissssss')) # None

# Borrar un elemento
del alumnos['Adolfo']
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Modificar la nota de Pepito
alumnos['Pepito'] = 5
print(alumnos)

# Eliminar el ultimo elemento
alumnos.popitem()
print(alumnos)

# Otra forma de agregar nuevo elemento
alumnos.update({'Pepito':5})
#alumnos.update({'Pepito':5, 'Juanito': 6})
print(alumnos)

# Ordenar el diccionario
print("Orden ascendente:", sorted(alumnos.values()))
print("Orden ascendente:", sorted(alumnos))
print("Orden descendente:", sorted(alumnos, reverse=True))

# Recorrer un diccionario
for alum in alumnos:  # Solo me devuelve las claves
    print(alum, alumnos[alum])
    
for item in alumnos.items(): # cada item es una tupla
    print(item)
    print(item[0], item[1])
    
for nombre, nota in alumnos.items(): # cada item es una tupla
    print(nombre, nota)
    
# Otras formas de crear diccionarios
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1) # No me permite repetir claves
alumnos = dict([('Juan', 6.4), ('Maria', 9.3), ('Luis', 6.4), ('Pepito', 5)])

# eliminar todos los elementos
alumnos.clear()
print(alumnos) # {}
