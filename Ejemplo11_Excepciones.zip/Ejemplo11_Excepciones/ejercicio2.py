'''
    Ejemplo del banco:
        - partimos de un saldo de 1000 euros
        - el usuario quiere retirar 1200, al ser insufiente lanzar excepcion
        
'''
saldo=1000

def retirar(importe):
    global saldo # esto me da acceso a la variable saldo
    if importe > saldo:
        raise Exception("No tienes saldo suficiente")
    else:
        saldo = saldo - importe

try:
    retirar(1200)
except Exception as ex:
    print(ex)
else:
    print("Saldo actual", saldo)