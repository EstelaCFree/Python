def solicitar_edad():
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # lanzar una excepcion
        raise Exception("La edad no puede ser negativa")
    else:
        return edad

try:
    edad = solicitar_edad()
except Exception as ex:
    print(ex)
else:
    print("Edad del usuario:", edad)