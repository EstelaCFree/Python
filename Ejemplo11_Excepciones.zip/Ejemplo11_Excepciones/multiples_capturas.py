'''
    Con esa lista se pretende convertir de texto a tipo int y sumar los valores
    al recorrer la lista por indice probar datos[5]
'''
# print(datos[5]) # IndexError:

datos = ['1', 'dos', '3', '4', '5']
suma = 0

for idx in range(len(datos) + 1):  # genera un rango de 0 a 5
    try:
        # acceder al dato
        dato = datos[idx]
        
        # lo convertimos a numero
        numero = int(dato)
        
    except (IndexError, ValueError, Exception) as error:
        print("Error de tipo", type(error))
        print("Mensaje de error", error)

    else:
        suma += numero

print("Suma:", suma)
